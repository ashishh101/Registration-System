package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistrationProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistrationProjectApplication.class, args);
	}

}
