package com.example.demo.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;

import jakarta.validation.Valid;

@Controller
public class UserController {

	@Autowired
	private UserRepository userRepo;
	
	@GetMapping("/")
	private String fpage() {
		return "login";
	}
	
	@GetMapping("/login")
	private String userLogin() {
		return "login";
	}
	
	@GetMapping("/signup")
	private String userSignup() {
		return "signup";
	}
	
	@PostMapping("/login")
	private String loginSuccess(@ModelAttribute User user, Model model) {
		
		user = userRepo.findByUsernameAndPassword(user.getUsername(), user.getPassword());
		if (user != null) {
			model.addAttribute("user", user.getUsername());
			return "home";
		}
		model.addAttribute("failed", "Invalid username or password");
		return "login";
	}
	
//	@PostMapping("/signup")
//	private String signupSuccess(@Valid @ModelAttribute User user) {
//		userRepo.save(user);
//		return "login";
//	}
	
	@PostMapping("/signup")
	public String signupSuccess(@Valid @ModelAttribute User user, BindingResult bindingResult, Model model) {
	    if (bindingResult.hasErrors()) {
	    	Map<String,List<String>> errors = new HashMap<>();
	    	List<FieldError> fe = bindingResult.getFieldErrors();
	    	for(FieldError f : fe) {
	    		if(errors.containsKey(f.getField())) {
	    			errors.get(f.getField()).add(f.getDefaultMessage());
	    		}else {
	    			errors.put(f.getField(), new ArrayList<>());
	    			errors.get(f.getField()).add(f.getDefaultMessage());
	    		}
	    	}
	    	model.addAttribute("error", errors);
	        return "signup";
	    }
	    userRepo.save(user);
	    return "login";
	}
}
