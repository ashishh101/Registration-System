package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;

@Controller
public class ListController {

	@Autowired
	private UserRepository userRepo;
	
	@GetMapping("/list")
	private String getList(Model model) {
		model.addAttribute("userdata", userRepo.findAll());
		return "list";
	}
	
	@GetMapping("/delete/{id}")
	private String deleteUser(@PathVariable int id) {
		
		userRepo.deleteById(id);
		return "redirect:/list";
	}
	
	@GetMapping("/edit/{id}")
	private String editUser(@PathVariable int id, Model model) {
		model.addAttribute("user", userRepo.getById(id));
		return "editForm";
	}
	
	@PostMapping("/edit")
	private String edit(@ModelAttribute User user) {
		
		userRepo.save(user);
		return "redirect:/list";
	}
}
